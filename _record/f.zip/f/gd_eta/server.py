import datetime
import json
import os
import random
import sys
import threading
import time
from multiprocessing import Process

import fastapi
import jwt
import orjson
import requests
from fastapi import Body, Query, HTTPException, Depends
from setuptools_scm import get_version
from starlette.background import BackgroundTasks
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.gzip import GZipMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from typing import Dict, Any, Callable, List

from common.config import setting
from common.model_enums import (
    REGION,
    IsLowFreq,
    GetReleaseStageByInt,
    ReleaseStage,
    GetReleaseStageInt,
)
from pb.lane_pb2 import Lane, Point, LaneRes
from service import ws, gd
from common.log import logger
from common.model import (
    RGSRequestModel,
    HTTPRequestModel,
    RGSResponseModel,
    LaneRequestModel,
    TRGSAreaRequestModel,
    RGSAreaRequestModel,
    RGSAreaResponseModel,
    TRGSAreaSegmentRequestModel,
    TRGSBlacklistRequestModel, LaneResponseModel,
)
from service.controller import (
    GetRouteResult,
    get_region,
    lane_request,
    GetAreaRouteResult,
    GetAreaSegmentRouteResult,
    GetBlacklistRouteResult,
)
from service.gd import getCount
from service.mapversion_check import get_all_map_version
from service.model import ShenzhenLane, refresh_map_lanes, RegionMapVersion
from service.ws import get_multi_mapversions, get_wsl_by_version
from fastapi import Response as fres


class ORJSONResponse(JSONResponse):
    media_type = 'application/json'

    def render(self, content: Any) -> bytes:
        return orjson.dumps(content, option=orjson.OPT_SERIALIZE_NUMPY)


def depends_jwtsigner(JwtSigner: str = fastapi.Header('')):
    def signer():
        with open('JWTSigner.pub', "r") as f:
            jwt.api_jwt.decode(
                JwtSigner, f.read(), algorithms=['RS256'], options={"verify_aud": False}
            )

    def signer_aliyun():
        with open('JWTaliyun.pub', "r") as f:
            jwt.api_jwt.decode(
                JwtSigner, f.read(), algorithms=['RS256'], options={"verify_aud": False}
            )

    e1, e2 = None, None
    try:
        signer()
    except Exception as e:
        e1 = str(e)
    try:
        signer_aliyun()
    except Exception as e:
        e2 = str(e)
    if e2 and e1:
        pass
    else:
        print(f'验证通过')
        # raise HTTPException(400, f'验证失败, 原因 {e1}, {e2}')


app = fastapi.FastAPI(
    default_response_class=ORJSONResponse,
    dependencies=[
        # Depends(depends_jwtsigner)
    ],
)
app.add_middleware(GZipMiddleware, minimum_size=500)


@app.middleware('http')
async def catch_exceptions_middleware(
    request: fastapi.Request,
    call_next: Callable[[fastapi.Request], fastapi.Response],
):
    try:
        return await call_next(request)
    except Exception as e:
        print(str(e))
        return fastapi.responses.ORJSONResponse(
            status_code=fastapi.status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                'detail': str(e),
                'code': 'FAIL',
            },
        )


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        '*',
    ],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


# Startup event handler
@app.on_event('startup')
async def startup():
    logger.info('server startup ok')


# Shutdown event handler
@app.on_event('shutdown')
async def shutdown():
    pass


def get_branch():
    with os.popen('git branch --show-current') as f:
        return f.read().strip()
    return ''


@app.get('/_version', response_model=str)
async def redirect():
    scm_version = get_version(
        root='.',
        relative_to=__file__,
        version_scheme='python-simplified-semver',
        local_scheme='node-and-timestamp',
    )
    return f"{get_branch()}/{scm_version}"


@app.get('/multi/map_versions', response_model=List[str])
async def redirect(region: REGION = Query(REGION.SHENZHEN)):
    return await get_multi_mapversions(region)


@app.post('/route_generation', response_model=RGSResponseModel)
async def route_generation(
    request_paths: bool = Query(False),
    map_version: str = Query(""),
    param: HTTPRequestModel = Body(...),
):
    region = get_region(param.regionName)
    return await GetRouteResult(
        request_paths, param, map_version=map_version, region=region
    )


@app.post('/blacklist/route_generation', response_model=RGSAreaResponseModel)
async def area_segment_route_generation(
    param: TRGSBlacklistRequestModel = Body(...),
):
    return await GetBlacklistRouteResult(param)


@app.post('/area/route_generation', response_model=RGSAreaResponseModel)
async def area_segment_route_generation(
    param: TRGSAreaRequestModel = Body(...),
):
    return await GetAreaRouteResult(param)


@app.post('/area/route_generation/segment', response_model=RGSAreaResponseModel)
async def area_route_generation(
    param: TRGSAreaSegmentRequestModel = Body(...),
):
    return await GetAreaSegmentRouteResult(param)


@app.get('/count', response_model=int)
async def count():
    return getCount()


@app.get('/lane_map_version')
async def lane_map_version():
    return RegionMapVersion.find()


@app.get('/refresh_map_lane', response_model=int)
async def refresh_map_lane(
    background_tasks: BackgroundTasks,
):
    return background_tasks.add_task(refresh_map_lanes)


@app.get('/api/closest/lane', response_model=LaneResponseModel)
async def closestLane(
    regionName: str = Query(...),
    releaseStage: int = Query(...),
    # centreLon: float = Query(...),
    # centreLat: float = Query(...),
    bbox: List[float] = Query(...),
):
    if len(bbox) != 4:
        raise Exception("phase bbox wrong")
    obj = lane_request(
        LaneRequestModel(
            region=get_region(regionName),
            releaseStage=releaseStage,
            limit=1,
            bbox=bbox,
            isCloseest=True,
        )
    )
    if not obj:
        raise HTTPException(400, f'not found closest lane')
    return LaneResponseModel(
        laneId=obj.get('lane_id', ''),
        segment=obj.get('segment', {}),
        multiReleaseStage=obj.get('multiReleaseStage', []),
    )


# @app.get('/api/test/map/lanes')
# async def count(
#     region: str = Query(...),
#     mapLayer: str = Query(...),
#     centreLon: float = Query(...),
#     centreLat: float = Query(...),
#     radius: int = Query(500),
#     limit: int = Query(10000),
#     skip: int = Query(0),
# ):
#     """
#     for test
#     """
#     param = LaneRequestModel(
#         region=get_region(region),
#         releaseStage=GetReleaseStageInt(mapLayer),
#         skip=skip,
#         limit=limit,
#         centreLon=centreLon,
#         centreLat=centreLat,
#         radius=radius,
#         toProtobuf=False,
#     )
#     obj = lane_request(param)
#     return obj
#
#
# @app.get('/api/test/map/lanes/count', response_model=int)
# async def count(
#     region: str = Query(...),
#     mapLayer: str = Query(...),
# ):
#     """
#     for test
#     """
#     param = LaneRequestModel(
#         region=get_region(region),
#         releaseStage=GetReleaseStageInt(mapLayer),
#         onlyCount=True,
#     )
#     obj = lane_request(param)
#     return obj


# @app.post(
#     '/lanes',
# )
# async def lanes(
#     param: LaneRequestModel = Body(...),
# ):
#     obj = lane_request(param)
#     return obj


@app.get(
    '/all_map_versions',
)
async def lanes():
    return await get_all_map_version()


@app.get(
    '/geoserver',
)
async def lanes(request: Request):
    query_params: Dict = dict(request.query_params)
    query_params.pop('CQL_FILTER', '')

    # 构造 cql_filter
    cql_filter = []
    for key in ('mapLayer', 'region', 'multiReleaseStage'):
        if key in query_params:
            val = query_params[key]
            if key == 'region':
                val = get_region(val).value
            query_params.pop(key)
            cql_filter.append(f"{key} in ('{val}')")
    if cql_filter:
        query_params['CQL_FILTER'] = ' AND '.join(cql_filter)

    r = requests.get(
        f'{setting.geo_server_uri}/geoserver/mongo/wms', params=query_params
    )
    response = Response(content=r.content, media_type="image/png")
    return response


# if __name__ == '__main__':
#     import requests
#
#     def _run(n):
#         print(f'线程 {n} 执行！')
#         t = time.time()
#         # s = requests.post(
#         #     'http://0.0.0.0:8765/lanes',
#         #     json={
#         #         "region": "shenzhen",
#         #         "releaseStage": 1,
#         #         "geoPolygon": [],
#         #         "only_ids": False,
#         #         "limit": 80000,
#         #         "skip": n * 80000,
#         #     },
#         # )
#         try:
#             # s = requests.get(
#             #     f'http://trgs-rgs.autox.clu:32067/api/v1/map/lanes?region=ShenZhen%2FPinShan&mapLayer=Pilot&limit=30000&skip={n*30000}'
#             # )
#             s = requests.get(
#                 f'http://127.0.0.1:8765/api/v1/map/lanes?region=ShenZhen%2FPinShan&mapLayer=Pilot&limit=30000&skip={n * 30000}'
#             )
#         except Exception as e:
#             print(e)
#         print(type(s.content), len(s.content), s.status_code)
#         res = LaneRes()
#         res.ParseFromString(s.content)
#         print(f'线程 {n} 结束, {len(res.lane)}, {len(s.content)}, {time.time() - t} ')
#
#     thread_num = 8
#     t_now = time.time()
#     threads = []
#     for i in range(thread_num):
#         t = threading.Thread(target=_run, args=(i,))
#         print(f'线程 {i} 开始!')
#         t.start()
#         threads.append(t)
#
#     for t in threads:
#         t.join()
#     print(f'最终时间 {time.time() - t_now}')
