from typing import Literal, Dict, Any, List

import pydantic

from common.model_enums import ReleaseStage, REGION, JunctionScenario, RoadCoverageWayType, RoadCoverageRateType


class Point(pydantic.BaseModel):
    lat: float
    lon: float


"""
RGS... for route-server websocket request
TRGS... for trgs http request
"""

class RGSRequestModel(pydantic.BaseModel):
    start_point: Point
    end_point: Point
    task_id: str
    time_limit: int
    type: Literal['RandomRouteRequest']
    use_junction_weight: bool = False
    release_stage: str = ReleaseStage.PILOT.value
    junction_scenario: str = JunctionScenario.Default.value
    use_scenario_weight: bool = False
    use_highway: bool = False
    blacklists: List[Dict] = []


class RGSAreaRequestModel(pydantic.BaseModel):
    task_id: str
    type: Literal['CoverageRouteRequest'] = 'CoverageRouteRequest'
    release_stage: str = ReleaseStage.PILOT.value
    lane_ids: List[str] = []
    use_highway: bool = False
    blacklists: List[Dict] = []
    filter_repeat: float = 0
    filter_junction: bool = False
    filter_side: bool = False
    # coverage: Dict = {}


class RGSAreaRequestMasterModel(pydantic.BaseModel):
    """
    请求 Rgs区域算路，正式环境model, 区分 RGSAreaRequestModel
    TODO: 等 全向/双向/单向 请求上线后, 统一为使用 RGSAreaRequestModel
    """
    task_id: str
    type: Literal['CoverageRouteRequest'] = 'CoverageRouteRequest'
    release_stage: str = ReleaseStage.PILOT.value
    lane_ids: List[str] = []
    use_highway: bool = False
    blacklists: List[Dict] = []


class RGSAreaSegmentRequestModel(pydantic.BaseModel):
    task_id: str
    type: Literal['CoverageSegmentRequest'] = 'CoverageSegmentRequest'
    num: List[int] = []
    roadPath: List[Dict] = []
    release_stage: str = ReleaseStage.PILOT.value


class RGSBlacklistRequestModel(pydantic.BaseModel):
    task_id: str
    type: Literal['CoverageSegmentRequest'] = 'BlacklistRouteRequest'
    start_point: Point
    blacklists: List[Dict] = []
    release_stage: str = ReleaseStage.PILOT.value


class TRGSBlacklistRequestModel(pydantic.BaseModel):
    regionName: str
    blacklists: List[Dict] = []
    startLocation: Point
    releaseStage: int = 3


class HTTPRequestModel(pydantic.BaseModel):
    startLocation: Point
    endLocation: Point
    durationMs: int
    regionName: str
    coverType: str
    releaseStage: int = 3
    junctionScenario: JunctionScenario = JunctionScenario.Default
    useScenarioWeight: bool = False
    # useJunctionWeight: bool = False
    # releaseStage: ReleaseStage = ReleaseStage.PILOT
    useHighway: bool = False
    blacklists: List[Dict] = []


class TRGSAreaRequestModel(pydantic.BaseModel):
    regionName: str
    releaseStage: int = 3
    geoPolygon: List[List[List]] = [[]]
    useHighway: bool = False
    blacklists: List[Dict] = []
    # filter_repeat: float = 0
    roadCoverageWayType: RoadCoverageWayType = RoadCoverageWayType.AllWay
    roadCoverageRateType: RoadCoverageRateType = RoadCoverageRateType.FullCoverage


class SegmentModel(pydantic.BaseModel):
    roadids: Dict = {}
    num: int = 1


class TRGSAreaSegmentRequestModel(pydantic.BaseModel):
    segments: List[SegmentModel] = []
    regionName: str = ''
    releaseStage: int = 3


class LaneRequestModel(pydantic.BaseModel):
    region: REGION = REGION.SHENZHEN
    releaseStage: int = 7
    geoPolygon: List[List[List]] = [[]]
    only_ids: bool = False
    onlyCount: bool = False
    skip: int = 0
    limit: int = 10000
    centreLon: float = 0
    centreLat: float = 0
    radius: int = 0
    toProtobuf: bool = True
    isCloseest: bool = False
    bbox: List[float] = []



class LaneResponseModel(pydantic.BaseModel):
    laneId: str
    segment: Dict
    multiReleaseStage: List[ReleaseStage]


class GDData(pydantic.BaseModel):
    distance: int
    duration: int
    code: str
    detail: str = ''
    point: List[Point] = []
    waypoints: List[str] = []
    use_rgs: bool = False


class RGSResponseModel(pydantic.BaseModel):
    rgs_data: Dict[str, Any]
    gd_data: GDData
    map_version: str = ''
    rgs_taskid: str = ''


class RGSAreaResponseModel(pydantic.BaseModel):
    rgs_data: Dict[str, Any]
    map_version: str = ''
    rgs_taskid: str = ''

