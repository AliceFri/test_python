from enum import Enum


class REGION(Enum):
    GUANGZHOU = 'guangzhou'
    SHENZHEN = 'shenzhen'
    SHANGHAI = 'shanghai'
    BEIJING = 'beijing'
    CHANGZHOU = 'changzhou'
    WUHU = 'wuhu'
    ZHAOQING = 'zhaoqing'
    WUHAN = 'wuhan'

    SanJose = 'san_jose'
    SanFrancisco = 'san_francisco'

class ReleaseStage(Enum):
    INITIAL = 'INITIAL'
    STRESS = 'STRESS'
    PILOT = 'PILOT'
    DRIVERLESS_STRESS = 'DRIVERLESS_STRESS'
    STRESS_TEST_MAP = 'STRESS_TEST_MAP'
    PREDICTION = 'PREDICTION'
    DRIVERLESS_PILOT = 'DRIVERLESS_PILOT'


class CoverType(Enum):
    Random = 'Random'
    LowFreq = 'Low Frequency'
    XTaxiRoute = 'xTaxi Route'
    Default = 'default'


def GetReleaseStageByInt(iStage: int) -> str:
    m = {
        1: ReleaseStage.INITIAL,
        2: ReleaseStage.STRESS,
        3: ReleaseStage.PILOT,
        4: ReleaseStage.DRIVERLESS_STRESS,
        5: ReleaseStage.STRESS_TEST_MAP,
        6: ReleaseStage.PREDICTION,
        7: ReleaseStage.DRIVERLESS_PILOT,
    }
    return m.get(iStage, ReleaseStage.PILOT).value


def GetReleaseStageInt(sStage: str) -> int:
    """
    for trgs test
    """
    return {
        'Initial': 1,
        'Strees Test': 2,
        'Pilot': 3,
        'Driverless Stress': 4,
        'Stress Test Map': 5,
        'Driverless Pilot': 7
    }.get(sStage, 3)


class JunctionScenario(Enum):
    ProtectedStraight = "Protected Straight"
    UnprotectedStraight = "Unprotected Straight"
    ProtectedLeft = "Protected Left"
    UnprotectedLeft = "Unprotected Left"
    ProtectedRight = "Protected Right"
    UnprotectedRight = "Unprotected Right"
    ProtectedUturn = "Protected Uturn"
    UnprotectedUturn = "Unprotected Uturn"
    Default = "None"


class RoadCoverageWayType(Enum):
    AllWay = "AllWay"   # 全向
    OneWay = "OneWay"   # 单向
    TwoWay = "TwoWay"   # 双向


class RoadCoverageRateType(Enum):
    Normal = "Normal"
    FullCoverage = "FullCoverage"


def IsLowFreq(s: str):
    return s == CoverType.LowFreq.value
