import random
from typing import List, Dict

from pydantic import BaseSettings

from common.model_enums import REGION


def generate_ws_url(port: int):
    # k8s 部署的 rgs-websocket 服务地址
    return f"ws://10.112.0.116:{str(port)}/random_route"


class Settings(BaseSettings):
    listen_port: int = 8765
    rgs_ws_uri: str = 'ws://127.0.0.1:38000/random_route'
    gd_base_url: str = 'https://restapi.amap.com/v3/direction/driving'
    gd_keys: List = [
        # 'f72d1bd09aab18ede88d0c126055244d',
        # 'fb7a1bcd71dc316a7fe600cbe523b1ed',
        '2da0ef17444abe7f7fec2385fd225a77'  # 企业账户的key
    ]
    route_nums: int = 1
    gd_route_points: int = 16
    rgs_time_out: float = 3.0
    valid_request_gd: bool = True

    # 深圳地区区分测试环境， 其他地区测试/正式环境请求同样的 rgs-websocket 服务
    test_multi_url = {
        REGION.SHENZHEN: [
            generate_ws_url(40445),
            generate_ws_url(42884),
        ]
    }

    multi_url: Dict[REGION, List[str]] = {
        REGION.SHENZHEN: [
            generate_ws_url(42884),
            generate_ws_url(50885),
        ],
        REGION.GUANGZHOU: [
            generate_ws_url(43564),
            generate_ws_url(42836),
        ],
        REGION.SHANGHAI: [
            generate_ws_url(44352),
            generate_ws_url(30034),
        ],
        REGION.BEIJING: [
            generate_ws_url(54436),
            generate_ws_url(52347),
        ],
        REGION.SanJose: [
            "ws://route-multi-latest:8765/random_route",
            "ws://route-multi-latest:8766/random_route",
            "ws://route-multi-latest:8767/random_route",
            "ws://route-multi-latest:8768/random_route",
            "ws://route-multi-latest:8769/random_route",
            # "ws://random-route-latest:8765/random_route",
            # "ws://rgs-us-route:8765/random_route"
        ],
    }

    rgs_mongodb_url: str = 'mongodb://trgs-rgs.autox.clu:44981/rgs'
    rgs_mongodb_db: str = 'rgs'
    rgs_ws_mapinfo_uri: str = 'ws://10.112.0.116:45715/random_route'
    is_us: bool = False
    is_test: bool = True

    geo_server_uri: str = 'http://trgs-rgs.autox.clu:41548'

    class Config:
        env_file = '.env'


setting = Settings()


def get_gd_key() -> str:
    """
    获取请求高德的企业账户key
    :return: str
    """
    return random.sample(setting.gd_keys, 1)[0]


def valid_request_gd() -> bool:
    """
    是否需要请求高德，获取eta和距离
    :return: bool
    """
    return setting.valid_request_gd


def is_test() -> bool:
    return setting.is_test

def useTestWebsocketServer(region):
    return region == REGION.SHENZHEN and setting.is_test
