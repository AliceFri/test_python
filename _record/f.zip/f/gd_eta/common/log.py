import logging
import sys


logger = logging.getLogger(__name__)
logger.setLevel('INFO')

handler = logging.StreamHandler(sys.stdout)


formatter = logging.Formatter(
    '{asctime} - {levelname:9} {name} - {filename}:{lineno}:{funcName} - {message}',
    style='{',
)
handler.setFormatter(formatter)
logger.addHandler(handler)
