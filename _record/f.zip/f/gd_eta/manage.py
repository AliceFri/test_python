import click
import os
from common.config import setting


@click.group()
def click_group():
    pass


@click_group.command()
@click.option('--host', default='0.0.0.0')
def start_server(host: str):
    cmd = f'uvicorn server:app --host {host} --port {setting.listen_port}  --reload --log-config ./uvicorn_log_config.json'
    os.system(cmd)


@click_group.command()
@click.option('--host', default='0.0.0.0')
def start_server_package(host: str):
    # # workers = os.cpu_count()
    # print(os.cpu_count())
    cmd = f'uvicorn server:app --host {host} --port {setting.listen_port} --workers 12 --log-config ./uvicorn_log_config.json'
    os.system(cmd)


@click_group.command()
@click.option('--region', default='shenzhen')
def refresh_map(region: str):
    pass


if __name__ == '__main__':
    click_group()
