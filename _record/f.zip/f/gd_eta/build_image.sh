#!/bin/bash

DOCKER_REG=hub.autox.tech/trgs/rgs_with_gdeta
git checkout master
git pull
docker build -t "$DOCKER_REG":master_latest .
docker push "$DOCKER_REG":master_latest