import asyncio

import requests

from common.config import setting
from service.mapversion_check import get_all_map_version


def notice_team(message):
    if not message:
        return
    message = f"""### RGS地图版本检查\n""" + message
    r = requests.post('https://vms.autox.tech:9443/notice_vms_team?is_env_notice=false', json=message)

def manage_message(map_versions):
    message = ''
    for r in map_versions.keys():
        latest_map_version = map_versions[r]['latest_map_version']
        route_version = map_versions[r]['route_version']
        lane_version = map_versions[r]['lane_version']
        if latest_map_version != route_version or latest_map_version != lane_version:
            message += f"""
{r.value}
最新地图版本:<font color="info">{latest_map_version}</font>
最新发布时间:<font color="info">{map_versions[r]['latest_map_time']}</font>
RGS规划地图:<font color="info">{route_version}</font>
RGSlane地图:<font color="info">{lane_version}</font>
"""
    return message


async def _main():
    map_versions = await get_all_map_version()
    message = manage_message(map_versions)
    notice_team(message)


if __name__ == '__main__':
    if not setting.is_test:
        asyncio.get_event_loop().run_until_complete(_main())
