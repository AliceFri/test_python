import json
import random
import time
from typing import List

from fastapi import HTTPException
from fastapi import Response as fres

from common.config import generate_ws_url, useTestWebsocketServer, is_test
from common.log import logger
from common.model import (
    HTTPRequestModel,
    RGSRequestModel,
    RGSResponseModel,
    LaneRequestModel,
    TRGSAreaRequestModel,
    RGSAreaRequestModel,
    RGSAreaResponseModel,
    TRGSAreaSegmentRequestModel,
    RGSAreaSegmentRequestModel,
    TRGSBlacklistRequestModel,
    RGSBlacklistRequestModel, RGSAreaRequestMasterModel,
)
from common.model_enums import (
    REGION,
    IsLowFreq,
    GetReleaseStageByInt,
    RoadCoverageRateType,
    RoadCoverageWayType,
)
from pb.lane_pb2 import LaneRes, Lane, Point
from service import ws, gd
from service.model import (
    ShenzhenLane,
    BeijingLane,
    GuangzhouLane,
    ShanghaiLane,
    SanjoseLane,
)
from service.ws import get_wsl_by_version, get_area_wsl, get_test_wsl, get_taskid


def log(title, data):
    logger.info(f' {title} data: {data} ')


async def GetRouteResult(
    request_paths: bool,
    param: HTTPRequestModel,
    map_version: str = "",
    region: REGION = REGION.SHENZHEN,
) -> RGSRequestModel:
    taskid = get_taskid()
    rgs_model = RGSRequestModel(
        start_point=param.startLocation,
        end_point=param.endLocation,
        task_id=taskid,
        time_limit=param.durationMs / 1000,
        type='RandomRouteRequest',
        use_junction_weight=IsLowFreq(param.coverType),
        release_stage=GetReleaseStageByInt(param.releaseStage),
        junction_scenario=param.junctionScenario.value,
        use_scenario_weight=param.useScenarioWeight,
        use_highway=param.useHighway,
        blacklists=param.blacklists,
    )
    wsurl, ver = await get_wsl_by_version(region, map_version)
    log('request', f'{wsurl}, {region}, {map_version}, {rgs_model.task_id}')
    log('param', f'{rgs_model.json()}')

    if not wsurl:
        raise HTTPException(400, f"该地区所选Rgs服务不可用")

    data = await ws.route_generation(rgs_model, wsurl)
    try:
        if not data.get('routeResult', {}).get('visualizeWaypoints'):
            log('no_visualizewaypoints', data)
    except Exception as e:
        logger.error(f'unknowerror {e}')
    gd_data = gd.request_gd_base(data, request_paths)
    if "result" in data:
        try:
            data['result'] = json.loads(data.get('result', ''))
            # 如果 gd_data 未请求到, 则使用 rgs 数据
            if gd_data.distance == 0 and gd_data.duration == 0:
                gd_data.distance = int(data.get('result', {}).get('distance', 0))
                gd_data.duration = int(data.get('result', {}).get('expected_time', 0))
                gd_data.use_rgs = True
        except Exception as e:
            logger.error(f'unknowerror1 {e}')
    res = RGSResponseModel(
        rgs_data=data, gd_data=gd_data, map_version=ver, rgs_taskid=taskid
    )
    return res


def get_region(region: str):
    maps = {
        'ShenZhen/PinShan': REGION.SHENZHEN,
        'ShenZhen/FuTian': REGION.SHENZHEN,
        'ShenZhen/NanShan': REGION.SHENZHEN,
        'GuangZhou': REGION.GUANGZHOU,
        'ShangHai': REGION.SHANGHAI,
        'BeiJing': REGION.BEIJING,
        'California/SanJose': REGION.SanJose,
        'California/SanFrancisco': REGION.SanFrancisco,
    }
    if region in maps:
        return maps[region]
    res = REGION.SHENZHEN
    if region == REGION.GUANGZHOU.value:
        res = REGION.GUANGZHOU
    elif region == REGION.BEIJING.value:
        res = REGION.BEIJING
    elif region == REGION.SHANGHAI.value:
        res = REGION.SHANGHAI
    elif region == REGION.SanJose.value:
        res = REGION.SanJose
    elif region == REGION.SanFrancisco.value:
        res = REGION.SanFrancisco
    return res


def lane_request(param: LaneRequestModel):
    obj = {
        REGION.SHENZHEN: ShenzhenLane,
        REGION.BEIJING: BeijingLane,
        REGION.GUANGZHOU: GuangzhouLane,
        REGION.SHANGHAI: ShanghaiLane,
        REGION.SanJose: SanjoseLane,
    }
    if param.region not in obj:
        return None
    aim_db = obj.get(param.region, ShenzhenLane)
    stage = GetReleaseStageByInt(param.releaseStage)
    query = {
        'multiReleaseStage': stage,
    }
    if param.only_ids:  # 查询给定polygon内的所有laneId
        query['segment'] = {
            '$geoWithin': {
                '$geometry': {'type': 'Polygon', 'coordinates': param.geoPolygon}
            }
        }
        objs = aim_db.no_ref_find(
            project={'lane_id': 1},
            **query,
        )
        return [o['lane_id'] for o in objs]

    if param.onlyCount:  # 仅仅查询给定region和图层的 lane数目
        return aim_db.count([{"$match": query}])

    if param.isCloseest:  # 有此参数就查离给定点最近的lane
        lon_min, lat_min, lon_max, lat_max = param.bbox
        query['segment'] = {'$geoIntersects': {
            '$geometry': {
                'type': "Polygon",
                'coordinates': [[
                    [lon_min, lat_min],
                    [lon_min, lat_max],
                    [lon_max, lat_max],
                    [lon_max, lat_min],
                    [lon_min, lat_min]
                ]]
            }
        }}
        return aim_db.get_collection().find_one(query)
    else:
        query['segment'] = {  # 查半径圆内的lane
            '$geoWithin': {
                '$centerSphere': [
                    [param.centreLon, param.centreLat],
                    param.radius / 6378100,
                ]
            }
        }
    objs = aim_db.no_ref_find(
        project={'segment': 1, "lane_id": 1},
        limit=param.limit,
        skip=param.skip,
        **query,
    )
    if not param.toProtobuf:
        return objs
    obj = parse_lane(objs)
    res = obj.SerializeToString()
    return fres(res)


def parse_lane(objs):
    return LaneRes(
        lane=[
            Lane(
                point=[Point(p=t) for t in obj['segment']['coordinates']],
            )
            for obj in objs
        ]
    )


async def GetAreaRouteResult(
    param: TRGSAreaRequestModel,
) -> RGSRequestModel:
    region = get_region(param.regionName)
    taskid = get_taskid()

    coverage = {'points': []}
    for p in param.geoPolygon[0]:
        coverage['points'].append({'lon': p[0], 'lat': p[1]})

    # if useTestWebsocketServer(region):
    #     lane_ids = []
    # else:
    lane_ids = lane_request(
        LaneRequestModel(
            region=region,
            releaseStage=param.releaseStage,
            geoPolygon=param.geoPolygon,
            only_ids=True,
        )
    )

    filter_repeat = (
        0 if param.roadCoverageRateType == RoadCoverageRateType.FullCoverage else 0.25
    )
    filter_junction, filter_side = False, False
    if param.roadCoverageWayType == RoadCoverageWayType.OneWay:
        filter_junction = True
    elif param.roadCoverageWayType == RoadCoverageWayType.TwoWay:
        filter_junction = True
        filter_side = True

    if is_test():
        rgs_model = RGSAreaRequestModel(
            task_id=taskid,
            release_stage=GetReleaseStageByInt(param.releaseStage),
            lane_ids=lane_ids,
            use_highway=param.useHighway,
            blacklists=param.blacklists,
            filter_repeat=filter_repeat,
            filter_junction=filter_junction,
            filter_side=filter_side,
        )
    else:
        rgs_model = RGSAreaRequestMasterModel(
            task_id=taskid,
            release_stage=GetReleaseStageByInt(param.releaseStage),
            lane_ids=lane_ids,
            use_highway=param.useHighway,
            blacklists=param.blacklists,
        )
    if not lane_ids and not useTestWebsocketServer(region):
        return RGSAreaResponseModel(rgs_data={'roadpoints': []})
    wsurl = await get_area_wsl(region)
    log('request area', f'{wsurl}, {region}, {rgs_model.task_id}')
    log('param lane ids: ', f'{len(lane_ids)}')
    if not wsurl:
        raise HTTPException(400, f"该地区所选Rgs服务不可用")

    data = await ws.area_route_generation(rgs_model, wsurl)
    res = RGSAreaResponseModel(rgs_data=data, rgs_taskid=taskid)
    return res


async def GetAreaSegmentRouteResult(
    param: TRGSAreaSegmentRequestModel,
) -> RGSRequestModel:
    region = get_region(param.regionName)
    taskid = get_taskid()
    rgs_model = RGSAreaSegmentRequestModel(
        task_id=taskid,
        type='CoverageSegmentRequest',
        num=[p.num for p in param.segments],
        roadPath=[p.roadids for p in param.segments],
        release_stage=GetReleaseStageByInt(param.releaseStage),
    )
    # print("================ RGS MODEL ==================")
    wsurl = await get_area_wsl(region)
    log('request area', f'{wsurl}, {region}, {rgs_model.task_id}')
    if not wsurl:
        raise HTTPException(400, f"该地区所选Rgs服务不可用")
    data = await ws.base_route_generation(rgs_model, wsurl)
    res = RGSAreaResponseModel(rgs_data=data, rgs_taskid=taskid)
    return res


async def GetBlacklistRouteResult(
    param: TRGSBlacklistRequestModel,
) -> RGSRequestModel:
    # print("1")
    region = get_region(param.regionName)
    taskid = get_taskid()
    rgs_model = RGSBlacklistRequestModel(
        task_id=taskid,
        start_point=param.startLocation,
        blacklists=param.blacklists,
        release_stage=GetReleaseStageByInt(param.releaseStage),
    )
    wsurl = await get_area_wsl(region)
    log('request blacklist', f'{wsurl}, {region}, {taskid}')
    if not wsurl:
        raise HTTPException(400, f"该地区所选Rgs服务不可用")
    data = await ws.base_route_generation(rgs_model, wsurl)
    res = RGSAreaResponseModel(rgs_data=data, rgs_taskid=taskid)
    return res
