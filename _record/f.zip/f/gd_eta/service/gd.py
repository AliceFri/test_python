import datetime
from typing import Dict
import requests
from common import config
from common.log import logger
from common.config import setting, valid_request_gd
from common.model import GDData
from utils import split_to_n_list, reduce_list_to_n
from utils.wgs import wgs_gcj
from ratelimit import limits, RateLimitException

__all__ = ['request_gd', 'request_gd_base', 'getCount']

SDAY = ''
COUNT = 0  # 记录当天调用次数


def trans_point(point: Dict) -> str:
    lon = float(point['lon'])
    lat = float(point['lat'])
    return wgs_gcj(lon, lat)


def parse_rgs_data(data):
    rs = data.get('routeResult')
    rq = data.get('request')
    ways = [rq.get('startPoint')] + rs.get('waypoints', []) + [rq.get('endPoint')]
    # 分成 setting.route_nums 段路
    ways = split_to_n_list(
        ways, setting.route_nums, min_num=setting.gd_route_points + 1
    )
    # 每段路取最多 18(起点 + 终点 + 16)个点
    ways = [reduce_list_to_n(w, setting.gd_route_points) for w in ways]
    return ways


def request_gd_base(data, request_paths=False) -> GDData:
    """
    请求高德, 获取数据 只返回 duration 和 distance
    """
    if not valid_request_gd():
        return GDData(
            distance=0,
            duration=0,
            code="Fail",
            detail="not open!",
            point=[],
            waypoints=[],
        )

    data = request_gd(data)
    res = GDData(
        distance=data.get('distance', 0),
        duration=data.get('duration', 0),
        code=data['code'],
        point=data.get('points', []),
        waypoints=data.get('waypoints', []),
    )
    if res.code == 'FAIL':
        res.detail = data.get('detail', '')
    if not request_paths:
        res.point = []
        res.waypoints = []
    return res


def request_gd(data):
    try:
        ways = parse_rgs_data(data)
    except Exception as e:
        # logger.error(f'解析 data 错误, data: {data}, e: {str(e)}')
        return {'detail': '解析 RGS 返回数据错误!', 'code': 'FAIL'}

    res = {
        'distance': 0,
        'duration': 0,
        'points': [],
        'waypoints': [],
        'code': 'OK',
    }
    for w in ways:
        origin, waypoints, destination = w
        origin, destination = trans_point(origin), trans_point(destination)
        waypoints = [trans_point(p) for p in waypoints]
        res['waypoints'].extend(waypoints)
        try:
            waypoints = ';'.join(waypoints)
            dur, dis, poi = gd_request_strategy1(origin, destination, waypoints)
            res['duration'] += dur
            res['distance'] += dis
            res['points'].extend(poi)
        except RateLimitException:
            return {'detail': 'Too Many Calls', 'code': 'FAIL'}
        except Exception as e:
            return {'detail': str(e), 'code': 'FAIL'}
    return res


def daycount():
    global SDAY, COUNT
    snow = datetime.datetime.now().strftime("-%Y%m%d")
    if snow != SDAY:
        SDAY = snow
        COUNT = 0
    COUNT += 1


def getCount():
    return COUNT


@limits(calls=10000, period=24 * 60 * 60)
@limits(calls=10, period=1)
def gd_request_strategy1(origin, destination, waypoints):
    daycount()  # 统计当天调用次数
    params = {
        'key': config.get_gd_key(),
        'origin': origin,
        'destination': destination,
        'waypoints': waypoints,
        'output': 'json',
        'extensions': 'base',
        'strategy': 0,
    }

    res = requests.get(f'{config.setting.gd_base_url}', params=params)
    if res.status_code != 200:
        raise Exception(f'请求高德服务失败 {res.status_code}')
    try:
        gdata = res.json()
        if gdata['status'] != '1':
            raise Exception(f'请求高德服务失败 {gdata["info"]}')
        path = gdata['route']['paths'][0]
        distance = int(path['distance'])
        duration = int(path['duration'])
        points = []
        for s in path['steps']:
            l = s['polyline'].split(';')
            l = [i.split(',') for i in l]
            points.extend([{"lon": float(i[0]), "lat": float(i[1])} for i in l])
        return duration, distance, points
    except Exception as e:
        logger.error(f'解析 GD data 错误, gdata: {gdata}, e: {str(e)}')
        raise Exception(f'解析 GD 返回数据错误!')
