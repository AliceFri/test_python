import asyncio
import json
import random
from typing import List

import websockets
from fastapi import HTTPException

from common.log import logger
from common.model import RGSRequestModel, RGSAreaRequestModel
from common.config import setting, useTestWebsocketServer

from common.model_enums import REGION

__all__ = [
    'route_generation',
    'get_multi_mapversions',
    'get_wsl_by_version',
    'get_area_wsl',
    'get_map_version',
    'get_taskid',
    'get_test_wsl',
]
GET_MAP_JSON = json.dumps({"type": "GetMapUID"})
# print(GET_MAP_JSON)


async def _route_generation_server(
    request_data: str,
    ws_url: str = "",
):
    rgs_ws_uri = ws_url if ws_url else setting.rgs_ws_uri
    async with websockets.connect(rgs_ws_uri, max_size=100 * 1024 * 1024, ping_timeout=300) as websocket:
        await websocket.send(request_data)
        data = await websocket.recv()
        data = json.loads(data)
        return data


async def route_generation(request_data: RGSRequestModel, ws_url: str = ""):
    """
    向 RGS 发送 websocket 请求, 带超时中断
    """
    try:
        data = await asyncio.wait_for(
            _route_generation_server(request_data.json(), ws_url),
            timeout=setting.rgs_time_out,
        )
    except asyncio.exceptions.TimeoutError:
        raise HTTPException(404, f"RGS 服务超时")
    return data


async def area_route_generation(request_data, ws_url: str = ""):
    """
    向 RGS 发送 websocket 请求, 带超时中断
    """
    try:
        data = await asyncio.wait_for(
            _route_generation_server(request_data.json(), ws_url),
            timeout=setting.rgs_time_out + 300,
        )
    except asyncio.exceptions.TimeoutError:
        raise HTTPException(404, f"RGS 服务超时")
    return data


async def base_route_generation(data, ws_url: str = ""):
    """
    向 RGS 发送 websocket 请求, 带超时中断
    """
    try:
        data = await asyncio.wait_for(
            _route_generation_server(data.json(), ws_url),
            timeout=setting.rgs_time_out + 300,
        )
    except asyncio.exceptions.TimeoutError:
        logger.info(f"data: {data.json()}")
        logger.info(f"ws_url: {ws_url}")
        raise HTTPException(404, f"RGS 服务超时")
    return data


async def get_map_version(ws_url: str = ''):
    """
    请求 地图版本, 若无则返回空
    """
    try:
        data = await asyncio.wait_for(
            _route_generation_server(GET_MAP_JSON, ws_url),
            timeout=1,
        )
        return data.get('uid', '')
    except Exception as e:
        logger.info(f'\nget_map_version_error: {ws_url} \n{e}\n')
    return ''

def get_usable_ws_urls(region: REGION):
    # 深圳地区区分 测试环境和正式环境, 其他地区调用的是同一个地区的 rgs服务
    if not useTestWebsocketServer(region):
        return setting.multi_url.get(region, [])
    return setting.test_multi_url.get(region, [])


async def get_multi_mapversions(region: REGION) -> List[str]:
    """
    获取 可支持的地图版本
    """
    wsls = get_usable_ws_urls(region)
    ans = []
    for wsl in wsls:
        ver = await get_map_version(wsl)
        if not ver:
            continue
        ans.append(ver)
    return ans


async def get_wsl_by_version(region: REGION, ver: str) -> str:
    """
    根据版本获取wsl, 返回 (wsl, version) 未找到则使用默认的
    """
    wsls = get_usable_ws_urls(region)
    default = None
    for wsl in wsls:
        ver1 = await get_map_version(wsl)
        if ver1 and not default:
            default = ver1
        if ver1 and ((not ver) or ver == ver1):
            return wsl, ver1
    return ver1, 'default'


async def get_area_wsl(region: REGION) -> str:
    """
    根据地区获取wsl, 总入口
    """
    wsurl, ver = await get_wsl_by_version(region, ver=None)
    return wsurl


async def get_test_wsl(region: REGION) -> str:
    """
    根据地区获取wsl, 返回
    """
    if region == REGION.SHENZHEN:
        return f"ws://10.112.0.116:40445/random_route", ''
    return '' , ''


def get_taskid() -> str:
    return str(random.randint(1000000, 9999999))
