import asyncio
import sys
import threading
import time
from enum import Enum
from typing import List

import pydantic
import pymongo

import orm
from common.config import setting
from common.model_enums import REGION
from orm.f import _BaseModel
from service.ws import get_area_wsl, get_map_version

orm.register_collection(
    setting.rgs_mongodb_url, setting.rgs_mongodb_db
)


class MapInfoType(Enum):
    LANE = 'LANE'
    PARKINGCURB = 'PARKINGCURB'


class LineString(pydantic.BaseModel):
    type: str = "LineString"
    coordinates: List[List[float]] = []


class ShenzhenParkingCurb(orm.BaseModel):
    lane_id: str        # 兼容之前的代码，这里统一为lane_id
    length: float = 0
    gcjSegment: LineString
    segment: LineString
    parkable: bool = False
    busParkable: bool = False
    level: int = -1
    levelId: int = -1
    multiReleaseStage: List[str] = []
    name: str = ''
    address: str = ''
    releaseStage: str = ''

    class Config:
        _indexs = [
            ['lane_id', {'unique': True}],
            ['multiReleaseStage', {}],
            [[('segment', pymongo.GEOSPHERE)]],
            [[('gcjSegment', pymongo.GEOSPHERE)]],
        ]


class ShenzhenLane(orm.BaseModel):
    lane_id: str
    length: float = 0
    gcjSegment: LineString
    segment: LineString
    roadId: str = ''
    level: int = -1
    levelId: int = -1
    multiReleaseStage: List[str] = []

    class Config:
        _indexs = [
            ['lane_id', {'unique': True}],
            ['multiReleaseStage', {}],
            [[('segment', pymongo.GEOSPHERE)]],
            [[('gcjSegment', pymongo.GEOSPHERE)]],
        ]


class GuangzhouLane(orm.BaseModel):
    lane_id: str
    length: float = 0
    gcjSegment: LineString
    segment: LineString
    level: int = -1
    levelId: int = -1
    roadId: str = ''
    multiReleaseStage: List[str] = []

    class Config:
        _indexs = [
            ['lane_id', {'unique': True}],
            ['multiReleaseStage', {}],
            [[('segment', pymongo.GEOSPHERE)]],
            [[('gcjSegment', pymongo.GEOSPHERE)]],
        ]


class ShanghaiLane(orm.BaseModel):
    lane_id: str
    length: float = 0
    gcjSegment: LineString
    segment: LineString
    level: int = -1
    levelId: int = -1
    roadId: str = ''
    multiReleaseStage: List[str] = []

    class Config:
        _indexs = [
            ['lane_id', {'unique': True}],
            ['multiReleaseStage', {}],
            [[('segment', pymongo.GEOSPHERE)]],
            [[('gcjSegment', pymongo.GEOSPHERE)]],
        ]


class BeijingLane(orm.BaseModel):
    lane_id: str
    length: float = 0
    gcjSegment: LineString
    segment: LineString
    level: int = -1
    levelId: int = -1
    roadId: str = ''
    multiReleaseStage: List[str] = []

    class Config:
        _indexs = [
            ['lane_id', {'unique': True}],
            ['multiReleaseStage', {}],
            [[('segment', pymongo.GEOSPHERE)]],
            [[('gcjSegment', pymongo.GEOSPHERE)]],
        ]


class SanjoseLane(orm.BaseModel):
    lane_id: str
    length: float = 0
    gcjSegment: LineString
    segment: LineString
    level: int = -1
    levelId: int = -1
    roadId: str = ''
    multiReleaseStage: List[str] = []

    class Config:
        _indexs = [
            ['lane_id', {'unique': True}],
            ['multiReleaseStage', {}],
            [[('segment', pymongo.GEOSPHERE)]],
            [[('gcjSegment', pymongo.GEOSPHERE)]],
        ]


class RegionMapVersion(orm.BaseModel):
    region: REGION
    map_version: str = ''
    map_type: MapInfoType = MapInfoType.LANE


def getZone(region: REGION):
    """
    获取region对应的 zone number
    """
    zone_config = {
        REGION.SHENZHEN: 49,
        REGION.SHANGHAI: 51,
        REGION.GUANGZHOU: 49,
        REGION.BEIJING: 50,
        REGION.SanJose: 10,
    }
    if region not in zone_config:
        raise Exception(f"not support getzone region: {region}")
    return zone_config.get(region)


def getTable(region: REGION, mapInfoType: MapInfoType):
    """
    获取对应的需要刷新的mongo collections
    """
    table_config = {
        REGION.SHENZHEN: {
            MapInfoType.LANE: ShenzhenLane,
            MapInfoType.PARKINGCURB: ShenzhenParkingCurb,
        },
        REGION.SHANGHAI: {
            MapInfoType.LANE: ShanghaiLane,
            # MapInfoType.PARKINGCURB: ShanghaiLane,
        },
        REGION.GUANGZHOU: {
            MapInfoType.LANE: GuangzhouLane,
            # MapInfoType.PARKINGCURB: GuangzhouLane,
        },
        REGION.BEIJING: {
            MapInfoType.LANE: BeijingLane,
            # MapInfoType.PARKINGCURB: BeijingLane,
        },
        REGION.SanJose: {
            MapInfoType.LANE: SanjoseLane,
            # MapInfoType.PARKINGCURB: SanjoseLane,
        },
    }
    if region not in table_config or mapInfoType not in table_config[region]:
        raise Exception(f"not support gettable {region} {mapInfoType}")
    return table_config[region][mapInfoType]


async def refresh_map_script(region: REGION, mapInfoType: MapInfoType = MapInfoType.LANE):
    """
    刷新 region 地区 地图信息
    :param mapInfoType:
    :param region:
    """

    print(f"begin!!! {region} {mapInfoType}")
    from utils.mapinfo_ws import get_map_laneids, get_map_parkingcurbs_ids, get_map_info

    zone, table = getZone(region), getTable(region, mapInfoType)

    wsurl = await get_area_wsl(region)
    if not wsurl:
        raise Exception(f"该地区所选Rgs服务不可用")
    mapVersion = await get_map_version(wsurl)
    obj = RegionMapVersion.find_one(region=region.value, map_type=mapInfoType.value)
    if obj and obj.map_version == mapVersion:
        print(f"已是该版本 {region} {mapInfoType} {mapVersion}")
        return

    ids = []
    if mapInfoType == MapInfoType.LANE:
        ids = await get_map_laneids(wsurl)
    elif mapInfoType == MapInfoType.PARKINGCURB:
        ids = await get_map_parkingcurbs_ids(wsurl)
    if not ids:
        raise Exception(f"获取 {mapInfoType} id信息出错!")
    print(f'all: {len(ids)}')
    thread_num = 10
    one_thread_task = (len(ids) + thread_num - 1) // thread_num

    async def thread_run(n, istart):  # 每个线程跑 one_thread_task 条数据
        iend = min(len(ids), istart + one_thread_task)
        await get_map_info(wsurl, ids[istart: iend], n, table, zone=zone, mapInfoType=mapInfoType)

    def run_count(n, istart):
        time.sleep(int(n[-1]))
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(thread_run(n, istart))

    t_start = time.time()
    threads = []
    for i in range(thread_num):
        t = threading.Thread(target=run_count, args=(f"t{i}", i * one_thread_task))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()
    print(f'最终时间: t_final {time.time() - t_start}')

    table.delete_many(lane_id={'$nin': ids})
    if obj:
        obj.update(map_version=mapVersion)
    else:
        obj = RegionMapVersion(region=region, map_version=mapVersion, map_type=mapInfoType)
        obj.save()
    print(f'finish!!!! {region} {mapInfoType}')


async def refresh_map_lanes():
    if setting.is_us:
        await refresh_map_script(REGION.SanJose)
    else:
        # await refresh_map_script(REGION.SHENZHEN, MapInfoType.PARKINGCURB)
        await refresh_map_script(REGION.BEIJING)
        await refresh_map_script(REGION.SHANGHAI)
        await refresh_map_script(REGION.GUANGZHOU)
        await refresh_map_script(REGION.SHENZHEN)


if __name__ == '__main__':
    asyncio.get_event_loop().run_until_complete(refresh_map_lanes())
