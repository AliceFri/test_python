import requests

from common.config import setting
from common.model_enums import REGION
from service.model import RegionMapVersion
from service.ws import get_area_wsl, get_wsl_by_version


def get_latest_map_version(region: REGION):
    url = f'https://cn-master.xmap.aitu.clu/map_builder/legacy_map_version_by_region?region={region.value}&num=1'
    if region == REGION.SanJose:
        url = f'https://us.id.autox.tech/map_builder/map_version_by_region?region={region.value}&num=1'
    res = requests.get(url, verify=False)
    maps = [d.get('latest_semantic_map_uid') for d in res.json()['data']]
    times = [d.get('created_at') for d in res.json()['data']]
    if maps:
        return maps[0], times[0]
    return '', ''

async def get_all_map_version():
    result = {}
    regions = [REGION.SanJose] if setting.is_us else [REGION.SHENZHEN, REGION.GUANGZHOU, REGION.BEIJING, REGION.SHANGHAI]
    for r in regions:
        result.setdefault(r, {})
        v, t = get_latest_map_version(r)
        result[r]['latest_map_version'] = v
        result[r]['latest_map_time'] = t
        _, route_version = await get_wsl_by_version(r, ver='')
        result[r]['route_version'] = route_version
        result[r]['lane_version'] = ''
        obj = RegionMapVersion.find_one(region=r.value)
        if obj and obj.map_version:
            result[r]['lane_version'] = obj.map_version
    return result
