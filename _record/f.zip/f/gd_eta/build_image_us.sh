#!/bin/bash


DOCKER_REG=registry.cn-shanghai.aliyuncs.com/autox/trgs
git checkout master-us
git pull
docker build -t "$DOCKER_REG":rgs_us_web_latest .
docker push "$DOCKER_REG":rgs_us_web_latest