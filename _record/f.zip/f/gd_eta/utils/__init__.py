from typing import List, Tuple


def split_to_n_list(l: List, n: int, min_num: int) -> List[List]:
    if len(l) % n == 0:
        cnt = len(l) // n
    else:
        cnt = len(l) // n + 1
    cnt = max(cnt, min_num)
    n = ((len(l) + 1) // cnt) + 1
    res = []
    for i in range(n):
        # 加1 是为了上一个数组的终点为下一个数组的起点
        res.append(l[i * cnt : (i + 1) * cnt + 1])
    res = [i for i in res if len(i) > 2]
    return res


def reduce_list_to_n(l: List, n: int) -> Tuple:
    """
    除起点和终点外, 最多保留 n 个点, 返回 起点，路径，终点
    """
    start = l.pop(0)
    end = l.pop(-1)
    if len(l) <= n:
        return start, l, end

    if len(l) % n == 0:
        cnt = len(l) // n
    else:
        cnt = len(l) // n + 1
    l = [i for ind, i in enumerate(l) if ind % cnt == 0]
    return start, l, end
