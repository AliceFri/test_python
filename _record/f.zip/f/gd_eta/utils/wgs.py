"""
WGS84 转 GCJ02
"""
import math

# 将WGS84坐标系转换为GCJ02火星坐标系
# 返回坐标字符串lon,lat

pi = 3.1415926535897932384626
a = 6378245.0
ee = 0.00669342162296594323

__all__ = ['wgs_gcj']


def wgs_gcj(lon, lat):
    dLat = transform_lat(lon - 105.0, lat - 35.0)
    dLon = transform_lon(lon - 105.0, lat - 35.0)
    radLat = lat / 180.0 * pi
    magic = math.sin(radLat)
    magic = 1 - ee * magic * magic
    sqrtMagic = math.sqrt(magic)
    dLat = (dLat * 180.0) / ((a * (1 - ee)) / (magic * sqrtMagic) * pi)
    dLon = (dLon * 180.0) / (a / sqrtMagic * math.cos(radLat) * pi)
    mgLat = lat + dLat
    mgLon = lon + dLon
    base = 10**6  # 保留 6 位小数
    mgLat = int(mgLat * base) / base
    mgLon = int(mgLon * base) / base
    return str(mgLon) + "," + str(mgLat)


def wgs_gcj_float(lon, lat):
    dLat = transform_lat(lon - 105.0, lat - 35.0)
    dLon = transform_lon(lon - 105.0, lat - 35.0)
    radLat = lat / 180.0 * pi
    magic = math.sin(radLat)
    magic = 1 - ee * magic * magic
    sqrtMagic = math.sqrt(magic)
    dLat = (dLat * 180.0) / ((a * (1 - ee)) / (magic * sqrtMagic) * pi)
    dLon = (dLon * 180.0) / (a / sqrtMagic * math.cos(radLat) * pi)
    mgLat = lat + dLat
    mgLon = lon + dLon
    base = 10**15  # 保留 15 位小数
    mgLat = int(mgLat * base) / base
    mgLon = int(mgLon * base) / base
    return mgLon, mgLat


def transform_lat(x, y):
    ret = (
        -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * math.sqrt(abs(x))
    )
    ret += (20.0 * math.sin(6.0 * x * pi) + 20.0 * math.sin(2.0 * x * pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(y * pi) + 40.0 * math.sin(y / 3.0 * pi)) * 2.0 / 3.0
    ret += (160.0 * math.sin(y / 12.0 * pi) + 320 * math.sin(y * pi / 30.0)) * 2.0 / 3.0
    return ret


def transform_lon(x, y):
    ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * math.sqrt(abs(x))
    ret += (20.0 * math.sin(6.0 * x * pi) + 20.0 * math.sin(2.0 * x * pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(x * pi) + 40.0 * math.sin(x / 3.0 * pi)) * 2.0 / 3.0
    ret += (
        (150.0 * math.sin(x / 12.0 * pi) + 300.0 * math.sin(x / 30.0 * pi)) * 2.0 / 3.0
    )
    return ret


from utm import to_latlon


def utm_to_latlon(x, y, zone=49):
    return to_latlon(x, y, zone, 'N')


def utm_to_lonlat(x, y, zone=49):
    t = to_latlon(x, y, zone, 'N')
    return t[1], t[0]


if __name__ == '__main__':
    # print(to_latlon(801800.9341417796, 2498145.3572805147, 49, 'N'))
    # print(to_latlon(459995.7716512866,  4404382.193719069, 50, 'N')[::-1])
    print(to_latlon(592322.7327008619, 4139001.38958475, 10, 'N')[::-1])
