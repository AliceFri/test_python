import asyncio
import json
import time
from typing import List, Dict

import websockets

from common.config import generate_ws_url, setting
from common.log import logger
from service.model import ShenzhenLane, LineString, MapInfoType
from service.ws import _route_generation_server, GET_MAP_JSON
from utils.wgs import utm_to_latlon, utm_to_lonlat, wgs_gcj_float

LANE_JSON = json.dumps({"type": "GetMapLaneList"})
PARKINGABLE_JSON = json.dumps({"type": "GetMapLaneBoundaryList"})


async def get_map_laneids(wsurl):
    """
    获取 lane ids
    """
    try:
        data = await asyncio.wait_for(
            _route_generation_server(LANE_JSON, wsurl),
            timeout=200,
        )
        return data.get('lanes', [])
    except Exception as e:
        logger.info(f'get map lanes list error: {e}')
    return []


async def get_map_parkingcurbs_ids(wsurl):
    """
    获取 parkingcurb ids
    """
    try:
        data = await asyncio.wait_for(
            _route_generation_server(PARKINGABLE_JSON, wsurl),
            timeout=200,
        )
        return data.get('lanes', [])
    except Exception as e:
        logger.info(f'get map parking curbs list error: {e}')
    return []


def getLineString(l: List, zone=49):
    """
    lane信息中 提取geojson LineString
    """
    p = []
    for d in l:
        if lp := d.get('lineSegment', {}).get('point', []):
            p.append(utm_to_lonlat(lp[0]['x'], lp[0]['y'], zone))
    if lp := l[-1].get('lineSegment', {}).get('point', []):
        if len(lp) >= 2:
            p.append(utm_to_lonlat(lp[1]['x'], lp[1]['y'], zone))
    return {
        'type': 'LineString',
        'coordinates': p,
    }


def getLineStringByPack(dpack: Dict, zone=49):
    """
    lane信息中 提取geojson LineString
    """
    p = []
    x, y = dpack['offset']['x'], dpack['offset']['y']
    for i in range(min(len(dpack['x']), len(dpack['y']))):
        p.append(utm_to_lonlat(x + dpack['x'][i], y + dpack['y'][i], zone))
    return {
        'type': 'LineString',
        'coordinates': p,
    }


def getGCJLineString(d):
    """
    84坐标系geojson(LineString) 转换为gcj坐标系(lineString)
    """
    p = []
    for l in d['coordinates']:
        lon, lat = wgs_gcj_float(l[0], l[1])
        p.append([lon, lat])
    return {
        'type': 'LineString',
        'coordinates': p,
    }


async def get_map_info(
        wsurl: str,
        ids: List[str],
        n,
        table,
        retry=0,
        zone=49,
        mapInfoType=MapInfoType.LANE,
):
    """
    请求获取地图信息, 并存进数据库
    :param wsurl: 获取信息的 websocket服务请求地址
    :param ids: 请求的 id 列表
    :param n: 线程标记(第n个线程)
    :param table: 存进该表
    :param retry: 重试次数，达到10请求失败
    :param zone: 坐标转换系数
    :param mapInfoType: 获取的地图类型
    """
    # 这里曾出现枚举类不是单例的奇怪现象，用value比较更加保险
    if mapInfoType.value not in [MapInfoType.LANE.value, MapInfoType.PARKINGCURB.value]:
        raise Exception(f"not support get map info {mapInfoType}")

    def getReqJson(_id):
        if mapInfoType.value == MapInfoType.LANE.value:
            _json = {"type": "GetMapLane", "lane_id": _id}
        else:
            _json = {"type": "GetMapLaneBoundary", "lane_boundary_id": _id}
        return json.dumps(_json)

    def manageLaneData(_data, _id):
        if 'centralCurvePack' in _data:
            segment = getLineStringByPack(_data['centralCurvePack'], zone)
        elif 'centralCurve' in _data:
            segment = getLineString(_data.get('centralCurve', {}).get('segment', []), zone)
        else:
            raise Exception(f'返回结果中不包含Curve信息')
        update = {
            'length': _data.get('length', 0),
            'gcjSegment': getGCJLineString(segment),
            'segment': segment,
            'level': _data.get('level', -1),
            'levelId': _data.get('levelId', -1),
            'multiReleaseStage': _data.get('multiReleaseStage', []),
            'roadId': _data.get('roadId', {}).get('id', ''),
        }
        if not (obj := table.find_one(lane_id=_id)):
            table.insert_one(
                lane_id=_id,
                **update,
            )
        else:
            obj.update(
                **update,
            )

    def manageParkingcurbData(_data, _id):
        if 'curvePack' in _data:
            segment = getLineStringByPack(_data['curvePack'], zone)
        else:
            raise Exception(f'返回结果中不包含Curve信息')
        update = {
            'length': _data.get('length', 0),
            'gcjSegment': getGCJLineString(segment),
            'segment': segment,
            'parkable': _data.get('parkable', False),
            'busParkable': _data.get('busParkable', False),
            'level': _data.get('level', -1),
            'levelId': _data.get('levelId', -1),
            'name': _data.get('name', ''),
            'address': _data.get('address', ''),
            'releaseStage': _data.get('releaseStage', ''),
            'multiReleaseStage': _data.get('multiReleaseStage', []),
        }
        if not (obj := table.find_one(lane_id=_id)):
            table.insert_one(
                lane_id=_id,
                **update,
            )
        else:
            obj.update(
                **update,
            )

    def manageData(_data, _id):
        if mapInfoType.value == MapInfoType.LANE.value:
            manageLaneData(_data, _id)
        else:
            manageParkingcurbData(_data, _id)

    try:
        async with websockets.connect(
            wsurl, max_size=10 * 1024 * 1024
        ) as websocket:
            icount = 0
            for ind, _id in enumerate(ids):
                req_json = getReqJson(_id)
                icount += 1
                if icount % 100 == 0:
                    print(f"{table.get_collection_name()} 线程 {n} {icount} ")
                try:
                    await websocket.send(req_json)
                    data = await websocket.recv()
                    data = json.loads(data).get('data', {})
                except Exception as e:
                    logger.info(f'\nget_map_lane_info_error_detail 线程{n}:  \n{e}\n')
                    continue
                manageData(data, _id)
    except Exception as e:
        if retry >= 10:
            logger.info(f'\n最终失败 {retry}:  \n{e}\n')
        time.sleep(1)
        logger.info(f'\n{n} 失败 {retry}:  \n{e}\n')
        await get_map_info(wsurl, ids[ind:], n, table, retry + 1, zone, mapInfoType)
