import os.path
import shutil
import sys
import threading
import time

if __name__ == '__main__':
    # 1. 删除 进程
    print("step1: delete the service")
    has_error = False
    try:
        for k in ('random',):
            with os.popen(f"ps -aux | grep {k} | grep -v grep") as f:
                l = f.readlines()
                for line in l:
                    try:
                        with os.popen(f"kill -9 {line.split()[1]}") as f1:
                            print(f.read().strip())
                    except Exception as e:
                        print(f"1 {e}")
                        has_error = True
    except Exception as e:
        print(f"2 {e}")
        has_error = True

    time.sleep(30)

    # 2. 准备 文件
    print("step2: move the file")
    base_path = '/maps/auto/multi'
    maps = {
        'sj1': ('san_jose_latest_tmp_1', 'san_jose_latest_bakmap_1'),
        'sj2': ('san_jose_latest_tmp_2', 'san_jose_latest_bakmap_2'),
        'sj3': ('san_jose_latest_tmp_3', 'san_jose_latest_bakmap_3'),
        'sj4': ('san_jose_latest_tmp_4', 'san_jose_latest_bakmap_4'),
        'sj5': ('san_jose_latest_tmp_5', 'san_jose_latest_bakmap_5'),
    }
    for region in maps.keys():
        tmp_path, source_path = maps.get(region)
        tmp_path, source_path = f'{base_path}/{tmp_path}', f'{base_path}/{source_path}'
        rgs_path = f'{base_path}/{region}'
        if os.path.exists(tmp_path) and len(os.listdir(tmp_path)) > 10:
            if os.path.exists(rgs_path):
                shutil.rmtree(rgs_path)
            os.rename(tmp_path, rgs_path)

        elif os.path.exists(rgs_path):
            pass

        else:
            if not os.path.exists(rgs_path):
                os.makedirs(rgs_path)
            with os.popen(f"cp {source_path}/* {rgs_path}/") as f:
                print(f.read().strip())
    # 3. 重新创建服务
    print("step3: restart the service")

    def thread_run(mapdir, p, index):
        with os.popen(
            f"/xurban/bazel-bin/infra/trgs/rgs/random_route_generation --get_lane_range=15.0 --time_to_cost_weight=1.8 --map_dir=/maps/auto/multi/{mapdir} --listening_ports={p} --coverage_split --coverage_inbound --coverage_use_random=false --coverage_min_rate=0.25 > /maps/log/random_route_generation_{index}.log"
        ) as f:
            print(f.read().strip())

    threads = []
    for i in range(1, 6):
        print(f'start {i}')
        port = 8764 + i
        t = threading.Thread(target=thread_run, args=(f'sj{str(i)}', str(port), str(i)))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()
