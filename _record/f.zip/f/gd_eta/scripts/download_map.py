import os
import datetime
import requests
import shutil
import time


def get_latest_map_version(region: str, num: int):
    url = f'https://us.id.autox.tech/map_builder/map_version_by_region?region={region}&num={num}'
    res = requests.get(url, verify=False)
    return [d.get('latest_semantic_map_uid') for d in res.json()['data']]


def write_log(msg):
    now = datetime.datetime.now()
    time_str = now.strftime("%Y-%m-%d %H:%M:%S")
    log_str = f"{time_str} {msg}\n"
    print(log_str)
    with open("/maps/log/random_route_generation.log", "a") as f:
        f.write(log_str)


def get_path():
    """
    返回下载地图的目录
    :return:
    """
    return '/maps/auto/multi'


if __name__ == '__main__':

    write_log("start!!!")
    maps = get_latest_map_version('san_jose', 5)
    print(maps)
    itime = 0
    file_path = get_path()  # /maps/auto
    for m in maps:
        itime += 1
        try:
            print(m)
            folder_path = f"{file_path}/san_jose_{str(itime)}"              # 下载到这个文件夹
            aim_path = f"{file_path}/san_jose_latest_bakmap_{str(itime)}"   # 复制到这个文件夹 （保证这个文件夹大多数时间是可用的）
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            print(m)
            with os.popen(
                f'bash /xurban/scripts/load_map.sh -u {m} -o {folder_path}'
            ) as f1:
                print(f'{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")} {f1.read().strip()}')
                # pass
            if len(os.listdir(folder_path)) > 10 and os.path.exists(f"{folder_path}/base_map_header.txt"):
                write_log(f"copy {m}")
                if os.path.exists(aim_path):
                    shutil.rmtree(aim_path)
                os.rename(folder_path, aim_path)
            else:
                if os.path.exists(folder_path):
                    shutil.rmtree(folder_path)
            print('sleep ...')
            time.sleep(10)
            print('sleep end')

        except Exception as e:
            write_log(f"finish!!! {e}")

    if (datetime.datetime.today().weekday() % 2) == 0 and os.path.exists(f"/root/.cache/semantic_map"):
        write_log(f"remove cache!!!")
        shutil.rmtree(f"/root/.cache/semantic_map")