import os
import datetime
import requests
import shutil
import time


def get_latest_map_version(region: str, num: int):
    url = f'https://cn.id.autox.tech/map_builder/map_version_by_region?region={region}&num={num}'
    res = requests.get(url, verify=False)
    return [d.get('latest_semantic_map_uid') for d in res.json()['data']]


def write_log(msg):
    now = datetime.datetime.now()
    time_str = now.strftime("%Y-%m-%d %H:%M:%S")
    log_str = f"{time_str} {msg}\n"
    with open("/xurban/log/random_route_generation.log", "a") as f:
        f.write(log_str)


def get_path():
    """
    返回下载地图的目录
    :return:
    """
    return '/volumn_maps/auto_maps'
#    return os.getenv('MAP_PATH', '/tmp')

def get_flag_path(region: str = ''):
    flag_path = "/home/quanxipeng/PycharmProjects/gd_eta/scripts/flag"
    if region:
        flag_path = f"{get_path()}/flags/{region}"
    return flag_path


def get_flag(region: str = ''):
    """
    获取下载地图的版本标识
    :return:
    """
    flag = ""
    try:
        with open(get_flag_path(region), "r") as f:
            flag = f.read()
    except Exception as e:
        pass
    return flag

def write_flag(region: str = '', map_version: str = ''):
    with open(get_flag_path(region), "w") as f:
        f.write(map_version)


if __name__ == '__main__':
    write_log("start!!!")
    file_path = get_path()      # /volumn_maps/auto_maps

    ti = datetime.datetime.now()

    for region in ('shanghai', 'beijing', 'guangzhou', 'shenzhen'):
        if ti.hour in (2, 3, 4, 5, 6):
            continue

        try:
            maps = get_latest_map_version(region, 1)
            write_log(f"{region} {' '.join(maps)}")
            flag_map = get_flag(region)
            if not maps:
                write_log(f"{region} get map failed")
                continue
            map_uid = maps[0]
            if map_uid == flag_map:
                write_log(f"{region} same mapversion {map_uid}")
                continue

            folder_path = f"{file_path}/{region}"              # 下载到这个文件夹
            aim_path = f"{file_path}/{region}_latest_bakmap"   # 复制到这个文件夹 （保证这个文件夹大多数时间是可用的）
            if os.path.exists(folder_path):
                shutil.rmtree(folder_path)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            with os.popen(
                f'bash /xurban/scripts/load_map.sh -u {map_uid} -o {folder_path}'
            ) as f1:
                print(f'{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")} {f1.read().strip()}')
                # pass
            if len(os.listdir(folder_path)) > 10 and os.path.exists(f"{folder_path}/base_map_header.txt"):
                write_log(f"copy {region} {map_uid}")
                if os.path.exists(aim_path):
                    shutil.rmtree(aim_path)
                os.rename(folder_path, aim_path)
                write_flag(region, map_uid)
            else:
                pass
                # if os.path.exists(folder_path):
                #     shutil.rmtree(folder_path)
            print('sleep ...')
            time.sleep(10)
            print('sleep end')

        except Exception as e:
            write_log(f"finish!!! {e}")

    if (datetime.datetime.today().weekday() % 4) == 0 and os.path.exists(f"/root/.cache/semantic_map"):
        write_log(f"remove cache!!!")
        shutil.rmtree(f"/root/.cache/semantic_map")