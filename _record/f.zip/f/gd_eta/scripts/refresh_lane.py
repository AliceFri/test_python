import asyncio
import service.model

if __name__ == '__main__':
    asyncio.get_event_loop().run_until_complete(service.model.refresh_map_lanes())

#
# >>> import service.model as m
# >>> m
# <module 'service.model' from '/app/service/model.py'>
# >>> import asyncio
# >>> asyncio.get_event_loop().run_until_complete(m.refresh_map_lanes())