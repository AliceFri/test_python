import shutil
import os
import datetime

def write_log(msg):
    now = datetime.datetime.now()
    time_str = now.strftime("%Y-%m-%d %H:%M:%S")
    log_str = f"{time_str} {msg}\n"
    with open("/maps/log/random_route_generation.log", "a") as f:
        f.write(log_str)


def get_path():
    """
    返回下载地图的目录
    :return:
    """
    return '/maps/auto/multi'


if __name__ == '__main__':

    base_path = get_path()      # /volumn_maps/auto_maps
    for source_file, aim_file in [
        ('san_jose_latest_bakmap_1', 'san_jose_latest_tmp_1'),
        ('san_jose_latest_bakmap_2', 'san_jose_latest_tmp_2'),
        ('san_jose_latest_bakmap_3', 'san_jose_latest_tmp_3'),
        ('san_jose_latest_bakmap_4', 'san_jose_latest_tmp_4'),
        ('san_jose_latest_bakmap_5', 'san_jose_latest_tmp_5'),
    ]:
        try:
            write_log(f"managing {aim_file}")
            source_path, aim_path = f"{base_path}/{source_file}", f"{base_path}/{aim_file}"
            if os.path.exists(aim_path):
                shutil.rmtree(aim_path)
            if not os.path.exists(aim_path):
                os.makedirs(aim_path)
            with os.popen(f"cp -r {source_path}/* {aim_path}/") as f:
                write_log(f.read().strip())
        except Exception as e:
            write_log(f"copy err {e}")